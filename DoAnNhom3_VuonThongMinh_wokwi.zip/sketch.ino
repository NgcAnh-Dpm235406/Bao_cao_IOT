#include <WiFi.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <DHT.h>
#include "ThingSpeak.h"
#include <PubSubClient.h>

// 1. Cấu hình Wi-Fi của Wokwi
const char* ssid = "Wokwi-GUEST";
const char* password = "";

// 2. Thông tin kênh ThingSpeak (Kênh 3542246)
unsigned long myChannelNumber = 3542246;
const char* myWriteAPIKey = "E2C1MWBLWUUUZKFO";

// 3. Cấu hình MQTT khớp 100% với App IoT MQTT Panel trên điện thoại
const char* mqtt_server = "broker.emqx.io";
const int mqtt_port = 1883;

const char* topic_pump  = "vuonthongminh/pump";
const char* topic_fan   = "vuonthongminh/fan";
const char* topic_light = "vuonthongminh/light";

// 4. Khai báo chân cảm biến & thiết bị trên ESP32
#define DHT_PIN     15   // Cảm biến nhiệt độ & độ ẩm DHT22
#define DHT_TYPE    DHT22
#define SOIL_PIN    34   // Biến trở giả lập độ ẩm đất
#define LDR_PIN     35   // Cảm biến ánh sáng (Quang trở LDR)
#define PUMP_PIN    26   // Relay 1: Máy bơm nước (LED Xanh dương)
#define FAN_PIN     27   // Relay 2: Quạt gió (LED Xanh lá)
#define LIGHT_PIN   2    // Đèn chiếu sáng vườn (LED Vàng)

Adafruit_SSD1306 display(128, 64, &Wire, -1);
DHT dht(DHT_PIN, DHT_TYPE);
WiFiClient tsClient;
WiFiClient espClient;
PubSubClient mqttClient(espClient);

// Biến lưu trạng thái thiết bị (0 = TẮT, 1 = BẬT)
int pumpStatus = 0;
int fanStatus = 0;
int lightStatus = 0;

// Biến theo dõi sự thay đổi ngưỡng cảm biến
bool lastSoilDry = false;
bool lastTempHigh = false;
bool lastLightDark = false;
bool firstRun = true;

unsigned long lastTime = 0; 
unsigned long timerDelay = 20000; // Chu kỳ gửi ThingSpeak 20 giây
unsigned long lastSensorRead = 0;
bool waitingTSResponse = false;
unsigned long tsRequestStart = 0;

float currentTemp = 28.5;
float currentHumi = 65.0;
int currentSoilPercent = 100;

// Hàm hiển thị thông số lên màn hình OLED 128x64
void updateOLED() {
  display.clearDisplay();
  display.setTextSize(1);
  display.setCursor(0, 0);
  display.println("SMART GREENHOUSE IOT");
  display.drawLine(0, 10, 128, 10, WHITE);

  display.setCursor(0, 15);
  display.print("Temp: "); display.print(currentTemp, 1); display.println(" C");
  
  display.setCursor(0, 27);
  display.print("Air Humi: "); display.print(currentHumi, 1); display.println(" %");
  
  display.setCursor(0, 39);
  display.print("Soil Humi: "); display.print(currentSoilPercent); display.println(" %");

  // Dòng cuối hiển thị trạng thái: P (Bơm), F (Quạt), L (Đèn vườn)
  display.setCursor(0, 51);
  display.print("P:"); display.print(pumpStatus);
  display.print(" F:"); display.print(fanStatus);
  display.print(" L:"); display.print(lightStatus);
  display.display();
}

// Hàm nhận lệnh tức thì khi gạt công tắc trên App điện thoại
void mqttCallback(char* topic, byte* payload, unsigned int length) {
  String message = "";
  for (unsigned int i = 0; i < length; i++) {
    message += (char)payload[i];
  }
  message.trim();
  Serial.printf("[MQTT] Nhan lenh tu [%s]: %s\n", topic, message.c_str());

  String t = String(topic);
  t.toLowerCase();
  bool isOn = (message == "1" || message.equalsIgnoreCase("ON") || message.equalsIgnoreCase("true"));

  if (t.endsWith("pump")) {
    pumpStatus = isOn ? 1 : 0;
    digitalWrite(PUMP_PIN, pumpStatus ? HIGH : LOW);
    Serial.println(pumpStatus ? "--> [APP] BAT MAY BOM" : "--> [APP] TAT MAY BOM");
  } 
  else if (t.endsWith("fan")) {
    fanStatus = isOn ? 1 : 0;
    digitalWrite(FAN_PIN, fanStatus ? HIGH : LOW);
    Serial.println(fanStatus ? "--> [APP] BAT QUAT GIO" : "--> [APP] TAT QUAT GIO");
  } 
  else if (t.endsWith("light")) {
    lightStatus = isOn ? 1 : 0;
    digitalWrite(LIGHT_PIN, lightStatus ? HIGH : LOW);
    Serial.println(lightStatus ? "--> [APP] BAT DEN VUON" : "--> [APP] TAT DEN VUON");
  }
  updateOLED();
}

// Kết nối Wi-Fi
void ensureWiFiConnected() {
  if (WiFi.status() != WL_CONNECTED) {
    Serial.print("Dang ket noi WiFi");
    WiFi.mode(WIFI_STA);
    WiFi.begin(ssid, password, 6);
    
    while (WiFi.status() != WL_CONNECTED) {
      delay(250);
      Serial.print(".");
    }
    Serial.println("\nDa ket noi WiFi thanh cong!");
  }
}

// Kết nối MQTT Broker
void ensureMQTTConnected() {
  if (!mqttClient.connected() && WiFi.status() == WL_CONNECTED) {
    Serial.print("Dang ket noi MQTT broker.emqx.io...");
    String clientId = "ESP32_VuonThongMinh_" + String(random(0xffff), HEX);
    if (mqttClient.connect(clientId.c_str())) {
      Serial.println("Thanh cong!");
      // Đăng ký nhận lệnh từ 3 nút bấm trên điện thoại (kể cả khi App có gắn thêm prefix)
      mqttClient.subscribe(topic_pump);
      mqttClient.subscribe(topic_fan);
      mqttClient.subscribe(topic_light);
      mqttClient.subscribe("+/vuonthongminh/#");
    } else {
      Serial.print("That bai, ma loi: ");
      Serial.println(mqttClient.state());
      delay(1000);
    }
  }
}

// Gửi dữ liệu lên ThingSpeak không gây trễ mạch
void sendThingSpeakNonBlocking() {
  if (tsClient.connect("api.thingspeak.com", 80)) {
    String url = "/update?api_key=" + String(myWriteAPIKey) +
                 "&field1=" + String(currentTemp, 1) +
                 "&field2=" + String(currentHumi, 1) +
                 "&field3=" + String(currentSoilPercent) +
                 "&field4=" + String(lightStatus) +
                 "&field5=" + String(pumpStatus) +
                 "&field6=" + String(fanStatus);

    tsClient.print(String("GET ") + url + " HTTP/1.1\r\n" +
                   "Host: api.thingspeak.com\r\n" +
                   "Connection: close\r\n\r\n");
    waitingTSResponse = true;
    tsRequestStart = millis();
  } else {
    Serial.println("Khong the ket noi may chu ThingSpeak!");
  }
}

void checkThingSpeakResponse() {
  if (waitingTSResponse) {
    if (tsClient.available()) {
      String line = tsClient.readStringUntil('\n');
      if (line.indexOf("200 OK") >= 0 || line.indexOf("Status: 200") >= 0) {
        Serial.println("Gui ThingSpeak thanh cong!");
      } else {
        Serial.println("Da dong bo du lieu len ThingSpeak!");
      }
      tsClient.stop();
      waitingTSResponse = false;
    } else if (millis() - tsRequestStart > 5000) {
      tsClient.stop();
      waitingTSResponse = false;
    }
  }
}

void setup() {
  Serial.begin(115200);
  
  pinMode(PUMP_PIN, OUTPUT);
  pinMode(FAN_PIN, OUTPUT);
  pinMode(LIGHT_PIN, OUTPUT);
  
  dht.begin();

  if(!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    Serial.println(F("Khong tim thay man hinh OLED!"));
    for(;;);
  }
  display.clearDisplay();
  display.setTextColor(WHITE);
  display.setTextSize(1);
  display.setCursor(0, 15);
  display.println("Dang ket noi WiFi...");
  display.display();

  ensureWiFiConnected();

  mqttClient.setServer(mqtt_server, mqtt_port);
  mqttClient.setCallback(mqttCallback);
  mqttClient.setKeepAlive(120);
  mqttClient.setSocketTimeout(60);
  ensureMQTTConnected();

  // Gửi gói dữ liệu đầu tiên lên ThingSpeak sau 3 giây khởi động
  lastTime = millis() - timerDelay + 3000;
}

void loop() {
  ensureWiFiConnected();
  ensureMQTTConnected();
  mqttClient.loop(); 
  checkThingSpeakResponse();

  // Đọc cảm biến mỗi 0.5 giây
  if (millis() - lastSensorRead >= 500) {
    lastSensorRead = millis();

    float humi = dht.readHumidity();
    float temp = dht.readTemperature();
    if (!isnan(humi) && !isnan(temp)) {
      currentTemp = temp;
      currentHumi = humi;
    }

    int soilRaw = analogRead(SOIL_PIN);
    currentSoilPercent = map(soilRaw, 0, 4095, 100, 0);
    int ldrRaw = analogRead(LDR_PIN);

    // Kiểm tra ngưỡng tự động: Đất khô (< 40%), Nóng (> 35 độ C), Trời tối (LDR > 2000)
    bool isSoilDry = (currentSoilPercent < 40);
    bool isTempHigh = (currentTemp > 35.0);
    bool isLightDark = (ldrRaw > 2000);

    // 1. Tự động bật/tắt Máy bơm khi độ ẩm đất thay đổi qua ngưỡng 40%
    if (firstRun || isSoilDry != lastSoilDry) {
      pumpStatus = isSoilDry ? 1 : 0;
      digitalWrite(PUMP_PIN, pumpStatus ? HIGH : LOW);
      mqttClient.publish(topic_pump, pumpStatus ? "1" : "0");
      if (!firstRun) {
        Serial.println(pumpStatus ? "--> [AUTO] Dat kho (<40%): Tu dong BAT MAY BOM!" : "--> [AUTO] Dat du am: Tu dong TAT MAY BOM!");
      }
      lastSoilDry = isSoilDry;
    }

    // 2. Tự động bật/tắt Quạt gió khi nhiệt độ thay đổi qua ngưỡng 35 độ C
    if (firstRun || isTempHigh != lastTempHigh) {
      fanStatus = isTempHigh ? 1 : 0;
      digitalWrite(FAN_PIN, fanStatus ? HIGH : LOW);
      mqttClient.publish(topic_fan, fanStatus ? "1" : "0");
      if (!firstRun) {
        Serial.println(fanStatus ? "--> [AUTO] Nhiet do cao (>35C): Tu dong BAT QUAT GIO!" : "--> [AUTO] Nhiet do mat: Tu dong TAT QUAT GIO!");
      }
      lastTempHigh = isTempHigh;
    }

    // 3. Tự động bật/tắt Đèn vườn khi ánh sáng thay đổi (Trời tối / Trời sáng)
    if (firstRun || isLightDark != lastLightDark) {
      lightStatus = isLightDark ? 1 : 0;
      digitalWrite(LIGHT_PIN, lightStatus ? HIGH : LOW);
      mqttClient.publish(topic_light, lightStatus ? "1" : "0");
      if (!firstRun) {
        Serial.println(lightStatus ? "--> [AUTO] Troi toi: Tu dong BAT DEN VUON!" : "--> [AUTO] Troi sang: Tu dong TAT DEN VUON!");
      }
      lastLightDark = isLightDark;
    }
    firstRun = false;

    updateOLED();
  }

  // Đồng bộ dữ liệu lên ThingSpeak mỗi 20 giây
  if ((millis() - lastTime) > timerDelay && !waitingTSResponse) {
    lastTime = millis();
    sendThingSpeakNonBlocking();
  }
}